-- MySQL dump 10.13  Distrib 8.3.0, for macos14.2 (arm64)
--
-- Host: db-mysql-sgp1-98767-do-user-8460446-0.c.db.ondigitalocean.com    Database: coke
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'bc30c9c5-0dd3-11ef-852b-3e309532c393:1-89';

--
-- Table structure for table `heroes`
--

DROP TABLE IF EXISTS `heroes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `heroes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `option` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `avatar` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heroes`
--

/*!40000 ALTER TABLE `heroes` DISABLE KEYS */;
INSERT INTO `heroes` VALUES (1,'Data Master','','data-master','Data Master',NULL,'assets/img/data-master.jpeg',NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2,'Problem Solver','','problem-solver','Problem Solver',NULL,'assets/img/problem-solver.png',NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(3,'Hero 3','','hero-3','No Name',NULL,'assets/img/hero-3.png',NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL);
/*!40000 ALTER TABLE `heroes` ENABLE KEYS */;

--
-- Table structure for table `histories`
--

DROP TABLE IF EXISTS `histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL DEFAULT '0',
  `hero_id` bigint NOT NULL DEFAULT '0',
  `track_id` bigint NOT NULL DEFAULT '0',
  `question_id` bigint NOT NULL DEFAULT '0',
  `description` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `answer` json DEFAULT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_track_id` (`track_id`),
  KEY `idx_question_id` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `histories`
--

/*!40000 ALTER TABLE `histories` DISABLE KEYS */;
INSERT INTO `histories` VALUES (1,6,2,0,2021,NULL,'{\"correct\": false}',NULL,'2024-04-15 08:31:14','2024-04-15 08:31:14',NULL),(2,6,2,0,2022,NULL,'{\"correct\": false}',NULL,'2024-04-15 08:31:18','2024-04-15 08:31:18',NULL),(3,6,2,0,2031,NULL,'{\"correct\": true}',NULL,'2024-04-15 08:31:47','2024-04-15 08:31:47',NULL),(4,7,2,0,2031,NULL,'{\"correct\": false}',NULL,'2024-04-15 08:33:15','2024-04-15 08:33:15',NULL),(5,7,2,0,2031,NULL,'{\"correct\": true}',NULL,'2024-04-15 08:33:23','2024-04-15 08:33:23',NULL),(6,7,2,0,2032,NULL,'{\"correct\": false}',NULL,'2024-04-15 08:34:17','2024-04-15 08:34:17',NULL),(7,7,2,0,2032,NULL,'{\"correct\": false}',NULL,'2024-04-15 08:34:22','2024-04-15 08:34:22',NULL),(8,7,2,0,2021,NULL,'{\"correct\": false}',NULL,'2024-04-16 14:35:32','2024-04-16 14:35:32',NULL),(9,7,2,0,2022,NULL,'{\"correct\": false}',NULL,'2024-04-16 14:35:45','2024-04-16 14:35:45',NULL),(10,7,2,0,2023,NULL,'{\"correct\": true}',NULL,'2024-04-16 14:35:56','2024-04-16 14:35:56',NULL),(11,7,2,0,2024,NULL,'{\"correct\": true}',NULL,'2024-04-16 14:36:20','2024-04-16 14:36:20',NULL),(12,6,2,0,2011,NULL,'{\"correct\": false}',NULL,'2024-04-19 12:48:21','2024-04-19 12:48:21',NULL),(13,6,2,0,2012,NULL,'{\"correct\": false}',NULL,'2024-04-19 12:48:28','2024-04-19 12:48:28',NULL),(14,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-19 12:48:38','2024-04-19 12:48:38',NULL),(15,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-19 12:48:48','2024-04-19 12:48:48',NULL),(16,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-19 12:48:52','2024-04-19 12:48:52',NULL),(17,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-19 12:49:00','2024-04-19 12:49:00',NULL),(18,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-24 04:36:03','2024-04-24 04:36:03',NULL),(19,2,1,0,1011,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:13:02','2024-04-25 03:13:02',NULL),(20,2,1,0,1011,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:20:17','2024-04-25 03:20:17',NULL),(21,2,1,0,1011,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:20:24','2024-04-25 03:20:24',NULL),(22,2,1,0,1011,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:23:54','2024-04-25 03:23:54',NULL),(23,2,1,0,1011,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:24:03','2024-04-25 03:24:03',NULL),(24,2,1,0,1012,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:24:23','2024-04-25 03:24:23',NULL),(25,2,1,0,1012,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:24:32','2024-04-25 03:24:32',NULL),(26,2,1,0,1013,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:25:02','2024-04-25 03:25:02',NULL),(27,2,1,0,1014,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:25:54','2024-04-25 03:25:54',NULL),(28,2,1,0,1014,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:26:00','2024-04-25 03:26:00',NULL),(29,2,1,0,1021,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:27:29','2024-04-25 03:27:29',NULL),(30,2,1,0,1022,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:29:25','2024-04-25 03:29:25',NULL),(31,2,1,0,1022,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:29:36','2024-04-25 03:29:36',NULL),(32,2,1,0,1023,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:29:59','2024-04-25 03:29:59',NULL),(33,2,1,0,1031,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:35:21','2024-04-25 03:35:21',NULL),(34,2,1,0,1034,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:40:50','2024-04-25 03:40:50',NULL),(35,2,2,0,2011,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:46:02','2024-04-25 03:46:02',NULL),(36,2,2,0,2011,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:46:08','2024-04-25 03:46:08',NULL),(37,2,2,0,2012,NULL,'{\"correct\": true}',NULL,'2024-04-25 03:47:49','2024-04-25 03:47:49',NULL),(38,2,2,0,2013,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:49:29','2024-04-25 03:49:29',NULL),(39,2,2,0,2013,NULL,'{\"correct\": false}',NULL,'2024-04-25 03:49:36','2024-04-25 03:49:36',NULL),(40,7,2,0,2035,NULL,'{\"correct\": true}',NULL,'2024-04-25 04:05:12','2024-04-25 04:05:12',NULL),(41,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-25 04:48:41','2024-04-25 04:48:41',NULL),(42,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-25 04:48:46','2024-04-25 04:48:46',NULL),(43,6,2,0,2014,NULL,'{\"correct\": false}',NULL,'2024-04-25 04:49:01','2024-04-25 04:49:01',NULL),(44,6,2,0,2024,NULL,'{\"correct\": false}',NULL,'2024-04-25 04:49:10','2024-04-25 04:49:10',NULL),(45,6,1,0,1011,NULL,'{\"correct\": false}',NULL,'2024-04-25 07:05:15','2024-04-25 07:05:15',NULL),(46,6,1,0,1011,NULL,'{\"correct\": true}',NULL,'2024-04-25 07:05:21','2024-04-25 07:05:21',NULL),(47,6,1,0,1012,NULL,'{\"correct\": true}',NULL,'2024-04-25 07:05:35','2024-04-25 07:05:35',NULL),(48,6,1,0,1013,NULL,'{\"correct\": true}',NULL,'2024-04-25 07:05:52','2024-04-25 07:05:52',NULL),(49,6,1,0,1014,NULL,'{\"correct\": false}',NULL,'2024-04-25 07:06:03','2024-04-25 07:06:03',NULL),(50,6,1,0,1014,NULL,'{\"correct\": false}',NULL,'2024-04-25 07:06:20','2024-04-25 07:06:20',NULL),(51,2,2,0,2011,NULL,'{\"correct\": false}',NULL,'2024-05-06 07:05:40','2024-05-06 07:05:40',NULL),(52,2,2,0,2011,NULL,'{\"correct\": false}',NULL,'2024-05-06 07:05:50','2024-05-06 07:05:50',NULL),(53,2,2,0,2011,NULL,'{\"correct\": true}',NULL,'2024-05-06 07:06:00','2024-05-06 07:06:00',NULL),(54,8,2,0,2011,NULL,'{\"correct\": false}',NULL,'2024-05-06 07:39:01','2024-05-06 07:39:01',NULL),(55,8,2,0,2011,NULL,'{\"correct\": false}',NULL,'2024-05-06 07:39:09','2024-05-06 07:39:09',NULL),(56,2,2,0,2014,NULL,'{\"correct\": true}',NULL,'2024-05-26 08:51:55','2024-05-26 08:51:55',NULL),(57,2,2,0,2024,NULL,'{\"correct\": false}',NULL,'2024-05-28 04:20:07','2024-05-28 04:20:07',NULL),(58,2,2,0,2035,NULL,'{\"correct\": false}',NULL,'2024-05-28 04:20:21','2024-05-28 04:20:21',NULL),(59,2,1,0,1012,NULL,'{\"correct\": true}',NULL,'2024-05-28 07:10:34','2024-05-28 07:10:34',NULL);
/*!40000 ALTER TABLE `histories` ENABLE KEYS */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (31,'2019_06_24_140207_create_saml2_tenants_table',1),(32,'2020_10_22_140856_add_relay_state_url_column_to_saml2_tenants_table',1),(33,'2020_10_23_072902_add_name_id_format_column_to_saml2_tenants_table',1),(34,'2024_02_05_091359_create_user_table',1),(35,'2024_02_05_091361_create_hero_table',1),(36,'2024_02_05_091362_create_track_table',1),(37,'2024_02_05_091616_create_question_table',1),(38,'2024_02_05_091633_create_record_table',1),(39,'2024_02_08_135147_create_history_table',1),(40,'2024_02_08_141748_create_rank_table',1),(41,'2024_03_28_113621_users_add_column_heros',2),(42,'2024_03_30_104936_add_fields_to_question_n_user',2),(43,'2024_04_09_182752_users_add_point_colume',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `track_id` bigint NOT NULL DEFAULT '0',
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `infer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `suggest` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `explain` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `option` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `avatar` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `template` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `table` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `background` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `answer` json DEFAULT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_track_id` (`track_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2041 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1011,101,'question-1','Câu 1','Business Planning','<p>Ngành hàng nào sẽ đóng góp nhiều nhất vào sự tăng trưởng của NARTD trong những năm tiếp theo?</p>\n<ul>\n<li>A. Beverage 5</li>\n<li>B. Beverage 11</li>\n<li>C. Beverage 7</li>\n<li>D. Beverage 9</li>\n</ul> ','',NULL,'',NULL,NULL,'game.track1.nv1.question1',NULL,NULL,1,'{\"answer\": \"D\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(1012,101,'question-2','Câu 2','Demand Planning','<p>Tìm Doanh thu Beverage 9 cần đạt của vùng Hà Nội trong năm 2024, biết: \n1. Doanh thu trung bình mỗi UC sản phẩm của 2023:12,000VND\n2. Mục tiêu tăng trưởng Doanh thu/UC của 2024 so với 2023: 1%\n3. Sản lượng đã bán trong năm 2023 là: 471.48UC\n4. Mục tiêu tăng trưởng sản lượng của 2024 so với 2023 là: 5%\n Doanh thu cần đạt của vùng Hà Nội trong năm 2024 là ... USD (làm tròn đến hàng triệu)</p>','<p>Ắt hẳn bạn đã có sự nhầm lẫn! Trước hết bạn cần tính mục tiêu tăng trưởng Doanh thu/UC của 2024, sau đó tính mục tiêu tăng trưởng sản lượng của 2024, từ đó mới ra được Doanh thu cần đạt</p>',NULL,'<p>Tại phòng Demand planning, bạn cần hết sức cẩn trọng, chi tiết, tỉ mỉ tính toán từ những con số lớn hàng năm cho đến những con số nhỏ nhất hàng ngày để đảm bảo phản ánh đúng nhu cầu thị trường!</p>',NULL,NULL,'game.track1.nv1.question2',NULL,NULL,1,'{\"answer\": \"6000000\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(1013,101,'question-3','Câu 3','Supply Planning','<p>Với 6,000,000 USD đã tính phía trên sẽ được tiếp tục chia nhỏ theo quý, tính toán kỹ từng SKU. Sau đó, Supply Planning sẽ tính nguyen vật liệu cần để sản xuất đáp ứng được nhu cầu của thị trường. Hãy nhìn vào ví dụ nhỏ dưới đây và điền vào ô xanh lá để hiểu một cách cơ bản nhất về công việc của Phòng Kế hoạch.</p>','',NULL,'',NULL,NULL,'game.track1.nv1.question3',NULL,NULL,1,'{\"answer\": \"A\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(1014,101,'question-4','Câu 4','MANUFACTURING - Processing','<p>Đầu tiên, khi tất cả các nguyen vật liệu cần đều đã được kiểm tra nghiêm ngặt và xác nhận đảm bảo chất lượng, bước đầu tiên trong hành trình tạo nên điều kỳ diệu chính là pha chế syrup.\nTheo kế hoạch sản xuất, thứ 4 cần cấp cho line 8 40 Unit Sprite. Phòng CSD quyết định pha syrup Sprite vào tank 7. Sau khi CIP, tạo barcode và đổ hương xong, một lượng nước sẽ tự động được thêm vào final tank theo barcode được tạo sẵn. Đợi 30 phút tuần hoàn, operator lấy mẫu ở final tank 7 (syrup đặc) để đo độ brix ở lab. Kết quả thu được brix fresh là 27.33oBrix. Tính lượng nước cần thêm vào (theo kg) để đạt được độ brix chuẩn theo MMI (26.23 ± 0.2) oBrix.\nBiết, theo MMI, lượng syrup khi pha 40 Unit là 14788 kg.\nLưu ý: Chỉ có thể thêm nước vào theo số chục chẵn. (Ví dụ: 20, 40, 60, 80, 100,...) Lượng nước cần thêm là: ... (Kg)</p>','',NULL,'',NULL,NULL,'game.track1.nv1.question4',NULL,NULL,1,'{\"answer\": \"580\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(1021,102,'question-1','Câu 1','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv1.question1',NULL,NULL,1,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1022,102,'question-2','Câu 2','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv1.question2',NULL,NULL,2,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1023,102,'question-3','Câu 3','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv1.question3',NULL,NULL,3,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1024,102,'question-3','Câu 4','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv1.question4',NULL,NULL,3,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1025,102,'question-3','Câu 5','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv1.question5',NULL,NULL,3,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1031,103,'question-1','Câu 1','Finance','','',NULL,'',NULL,NULL,'game.track3.nv1.question1',NULL,NULL,1,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1032,103,'question-2','Câu 2','Finance','','',NULL,'',NULL,NULL,'game.track3.nv1.question2',NULL,NULL,2,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1033,103,'question','Câu hỏi','Legal','','',NULL,'',NULL,NULL,'game.track3.nv1.question3',NULL,NULL,3,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1034,103,'question-1','Câu hỏi 1','PACS','','',NULL,'',NULL,NULL,'game.track3.nv1.question4',NULL,NULL,4,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1035,103,'question-2','Câu hỏi 2','PACS','','',NULL,'',NULL,NULL,'game.track3.nv1.question5',NULL,NULL,5,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1036,103,'question','Câu hỏi','People','','',NULL,'',NULL,NULL,'game.track3.nv1.question6',NULL,NULL,6,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(1037,102,'question-2','Câu 7','Selling','','',NULL,'',NULL,NULL,'game.track3.nv1.question7',NULL,NULL,7,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2011,201,'question-1','Câu 1','Business Planning','<p>Kéo thả matching</p>','',NULL,'',NULL,NULL,'game.track1.nv2.question1',NULL,NULL,1,'{\"answer\": \"A\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(2012,201,'question-2','Câu 2','Demand Planning','<p>Trong giai đoạn cuối năm 2023, kênh KA OFF tại vùng HCM được dự báo sẽ bán 50 ngàn thùng COCA- COLA SLEEK CAN 320M trong tuần cuối tháng 11. Tuy nhiên, thực tế chúng ta bán được tốt hơn dự kiến. Đâu có thể là lý do cho việc này?\na. Coke bán số lượng rất lớn sản phẩm cho khách hàng với giá thấp trong tuần cuối tháng 11, đơn hàng này phát sinh ngoài kế hoạch dự báo.\nb. Coke chạy các chương trình khuyến mãi cho khách hàng trong tuần cuối tháng 11, thu hút một số lượng lớn khách hàng sử dụng sản phẩm.\nc. Đối thủ chạy các chương trình khuyến mãi đặt biệt trong tuần cuối tháng 11 nhưng không cạnh tranh bằng Coke khiến cho khách hàng từ trung thành của đối thủ chuyển sang sử dụng sản phẩm của Coke.</p>','',NULL,'',NULL,NULL,'game.track1.nv2.question2',NULL,NULL,1,'{\"answer\": \"A\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(2013,201,'question-3','Câu 3','Supply Planning','<p>Vào mùa tết, nhu cầu thị trường miền Bắc tăng đột biến cho sản phẩm Fanta Cam, lon 320ml carton Tết, tồn kho của nguyên vật liệu sản xuất Fanta Cam không đủ để đáp ứng sự gia tăng đó.\nHương liệu được mua dựa trên nhu cầu của từng vùng sản xuất.\nHãy cho biết những phương án khả thi để giải quyết tình huống trên.\n5 phương án dưới đây sẽ được xáo trộn khác nhau cho mỗi nhân viênnhiệm vụ của người chơi là kéo thả các phương án theo đúng thứ tự ưu tiên</p>','',NULL,'',NULL,NULL,'game.track1.nv2.question3',NULL,NULL,1,'{\"answer\": \"A\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(2014,201,'question-4','Câu 4','Supply Planning','<p>Chương trình Summer UTC là một trong những chương trình lớn nhất của mùa hè, vì thiết kế sản phẩm có sự khác biệt so với phiên bản thông thường nên đòi hỏi nguyên vật liệu phải được chuẩn bị từ trước để phục vụ cho đợt tung sản phẩm vào đầu tháng 5.\nBiết rằng:\n- Thời gian cần cho việc sản xuất và đưa sản phẩm ra thị trường là: 2 tuần\n- Thời gian cần cho việc đặt hương liệu sản xuất là: 8 tuần\n- Thời gian cần cho việc đặt lon/preform (sản xuất vỏ chai) là: 6 tuần\n- Thời gian cần cho việc đặt nắp lon/chai là: 5 tuần\n- Thời gian cần cho việc đặt carton/ màng co là: 2 tuần\nBiết tuần cần launching là tuần 18 của năm 2024, hãy cho biết thời gian cụ thể cho việc đặt nắp lon, carton\nLưu ý: leadtime của nguyên vật liệu phải được tính trước thời điểm sản xuất</p>','',NULL,'',NULL,NULL,'game.track1.nv2.question4',NULL,NULL,1,'{\"answer\": \"A\"}',NULL,'2024-03-27 20:00:41','2024-03-27 20:00:41',NULL),(2021,202,'question-1','Câu hỏi 1','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv2.question1',NULL,NULL,1,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2022,202,'question-2','Câu hỏi 2','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv2.question2',NULL,NULL,2,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2023,202,'question-3','Câu hỏi 3','Distributing','','',NULL,'',NULL,NULL,'game.track2.nv2.question3',NULL,NULL,3,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2024,202,'question-1','Thử thách xếp tủ lạnh','Selling','','',NULL,'',NULL,NULL,'game.track2.nv2.question4',NULL,NULL,6,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2031,203,'question-1','Question 1','Finance','','',NULL,'',NULL,NULL,'game.track3.nv2.question1',NULL,NULL,1,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2032,203,'question-2','Question 2','Finance','','',NULL,'',NULL,NULL,'game.track3.nv2.question2',NULL,NULL,2,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2033,203,'question-1','Question 1','IT','','',NULL,'',NULL,NULL,'game.track3.nv2.question3',NULL,NULL,3,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2034,203,'question-2','Question 2','IT','','',NULL,'',NULL,NULL,'game.track3.nv2.question4',NULL,NULL,4,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(2035,203,'error-1','Error 1','IT','','',NULL,'',NULL,NULL,'game.track3.nv2.question5',NULL,NULL,5,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;

--
-- Table structure for table `ranks`
--

DROP TABLE IF EXISTS `ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ranks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL DEFAULT '0',
  `hero_id` bigint NOT NULL DEFAULT '0',
  `track_id` bigint NOT NULL DEFAULT '0',
  `point` tinyint NOT NULL DEFAULT '0',
  `bonus` tinyint NOT NULL DEFAULT '0',
  `description` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_track_id` (`track_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranks`
--

/*!40000 ALTER TABLE `ranks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ranks` ENABLE KEYS */;

--
-- Table structure for table `records`
--

DROP TABLE IF EXISTS `records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL DEFAULT '0',
  `hero_id` bigint NOT NULL DEFAULT '0',
  `track_id` bigint NOT NULL DEFAULT '0',
  `question_id` bigint NOT NULL DEFAULT '0',
  `times` tinyint NOT NULL DEFAULT '1',
  `point` float NOT NULL DEFAULT '0',
  `answer` json DEFAULT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_hero_id` (`hero_id`),
  KEY `idx_question_id` (`question_id`),
  KEY `idx_point` (`point`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records`
--

/*!40000 ALTER TABLE `records` DISABLE KEYS */;
INSERT INTO `records` VALUES (1,2,2,201,2011,2,0.5,'{\"correct\": true}',NULL,'2024-05-06 07:05:59','2024-05-06 07:05:59',NULL),(2,2,1,101,1011,2,0.5,'{\"correct\": true}',NULL,'2024-04-25 03:24:03','2024-04-25 03:24:03',NULL),(3,6,2,202,2021,1,0,'{\"correct\": false}',NULL,'2024-04-15 08:31:14','2024-04-15 08:31:14',NULL),(4,6,2,202,2022,1,0,'{\"correct\": false}',NULL,'2024-04-15 08:31:18','2024-04-15 08:31:18',NULL),(5,6,2,203,2031,1,1,'{\"correct\": true}',NULL,'2024-04-15 08:31:47','2024-04-15 08:31:47',NULL),(6,7,2,203,2031,2,0.5,'{\"correct\": true}',NULL,'2024-04-15 08:33:23','2024-04-15 08:33:23',NULL),(7,7,2,203,2032,1,0,'{\"correct\": false}',NULL,'2024-04-15 08:34:22','2024-04-15 08:34:22',NULL),(8,7,2,202,2021,1,0,'{\"correct\": false}',NULL,'2024-04-16 14:35:32','2024-04-16 14:35:32',NULL),(9,7,2,202,2022,1,0,'{\"correct\": false}',NULL,'2024-04-16 14:35:45','2024-04-16 14:35:45',NULL),(10,7,2,202,2023,1,1,'{\"correct\": true}',NULL,'2024-04-16 14:35:56','2024-04-16 14:35:56',NULL),(11,7,2,202,2024,1,1,'{\"correct\": true}',NULL,'2024-04-16 14:36:20','2024-04-16 14:36:20',NULL),(12,6,2,201,2011,1,0,'{\"correct\": false}',NULL,'2024-04-19 12:48:21','2024-04-19 12:48:21',NULL),(13,6,2,201,2012,1,0,'{\"correct\": false}',NULL,'2024-04-19 12:48:28','2024-04-19 12:48:28',NULL),(14,6,2,201,2014,1,0,'{\"correct\": false}',NULL,'2024-04-25 04:49:01','2024-04-25 04:49:01',NULL),(15,2,1,101,1012,1,0,'{\"correct\": false}',NULL,'2024-04-25 03:24:32','2024-04-25 03:24:32',NULL),(16,2,1,101,1013,1,1,'{\"correct\": true}',NULL,'2024-04-25 03:25:02','2024-04-25 03:25:02',NULL),(17,2,1,101,1014,2,0.5,'{\"correct\": true}',NULL,'2024-04-25 03:26:00','2024-04-25 03:26:00',NULL),(18,2,1,102,1021,1,1,'{\"correct\": true}',NULL,'2024-04-25 03:27:29','2024-04-25 03:27:29',NULL),(19,2,1,102,1022,2,0.5,'{\"correct\": true}',NULL,'2024-04-25 03:29:36','2024-04-25 03:29:36',NULL),(20,2,1,102,1023,1,1,'{\"correct\": true}',NULL,'2024-04-25 03:29:59','2024-04-25 03:29:59',NULL),(21,2,1,103,1031,1,1,'{\"correct\": true}',NULL,'2024-04-25 03:35:21','2024-04-25 03:35:21',NULL),(22,2,1,103,1034,1,1,'{\"correct\": true}',NULL,'2024-04-25 03:40:50','2024-04-25 03:40:50',NULL),(23,2,2,201,2012,1,0,NULL,NULL,'2024-04-25 03:47:49','2024-04-25 03:47:49',NULL),(24,2,2,201,2013,1,0,NULL,NULL,'2024-04-25 03:49:29','2024-04-25 03:49:29',NULL),(25,7,2,203,2035,1,1,'{\"correct\": true}',NULL,'2024-04-25 04:05:12','2024-04-25 04:05:12',NULL),(26,6,2,202,2024,1,0,'{\"correct\": false}',NULL,'2024-04-25 04:49:10','2024-04-25 04:49:10',NULL),(27,6,1,101,1011,1,0,NULL,NULL,'2024-04-25 07:05:15','2024-04-25 07:05:15',NULL),(28,6,1,101,1012,1,0,NULL,NULL,'2024-04-25 07:05:35','2024-04-25 07:05:35',NULL),(29,6,1,101,1013,1,0,NULL,NULL,'2024-04-25 07:05:52','2024-04-25 07:05:52',NULL),(30,6,1,101,1014,1,0,NULL,NULL,'2024-04-25 07:06:03','2024-04-25 07:06:03',NULL),(31,8,2,201,2011,1,0,'{\"correct\": false}',NULL,'2024-05-06 07:39:09','2024-05-06 07:39:09',NULL),(32,2,2,201,2014,1,1,'{\"correct\": true}',NULL,'2024-05-26 08:51:55','2024-05-26 08:51:55',NULL),(33,2,2,202,2024,1,0,'{\"correct\": false}',NULL,'2024-05-28 04:20:07','2024-05-28 04:20:07',NULL),(34,2,2,203,2035,1,0,'{\"correct\": false}',NULL,'2024-05-28 04:20:21','2024-05-28 04:20:21',NULL);
/*!40000 ALTER TABLE `records` ENABLE KEYS */;

--
-- Table structure for table `saml2_tenants`
--

DROP TABLE IF EXISTS `saml2_tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saml2_tenants` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `idp_entity_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `idp_login_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `idp_logout_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `idp_x509_cert` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `metadata` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `relay_state_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name_id_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'persistent',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saml2_tenants`
--

/*!40000 ALTER TABLE `saml2_tenants` DISABLE KEYS */;
INSERT INTO `saml2_tenants` VALUES (10,'sso','_4b5dfc05-8006-4680-bce0-9777574b081e','https://sts.windows.net/a2f7095f-5748-4c1f-8098-c0b617027032/','https://login.microsoftonline.com/a2f7095f-5748-4c1f-8098-c0b617027032/saml2','https://login.microsoftonline.com/a2f7095f-5748-4c1f-8098-c0b617027032/saml2','MIIC8DCCAdigAwIBAgIQKkDWY/hPSphN9PLK5yKlEzANBgkqhkiG9w0BAQsFADA0MTIwMAYDVQQDEylNaWNyb3NvZnQgQXp1cmUgRmVkZXJhdGVkIFNTTyBDZXJ0aWZpY2F0ZTAeFw0yNDAyMjcwODI4MDNaFw0yNzAyMjcwODI4MDNaMDQxMjAwBgNVBAMTKU1pY3Jvc29mdCBBenVyZSBGZWRlcmF0ZWQgU1NPIENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwlR9RP7VOcli3MXMdkbE116lk9/r0TXVLDdM2S8qhV6pi7M7iXl9LtoJDRC2+ZfgsUzW3s3AkQR2dAKwKoCixyVDqi0W+sXYLKWDJX7/eUjBW+nVLUMFESmsO1xFbl//fj4iLaOZDo4T3lv2D/f7kWxabQB4TfhFbu7wknJrWlpTpn+0bfTXlPSo2QmDVcF0ETONybbNiq/E4NITt0LeT5fpwnw7I+JNpXqdBhPBRvbNZeRLjxRQegKDU1FwDHqq8e1Jk94/ECxoh/B/X9pJ+7ksBXNh8s66bqvVsHpPFEjqM1U+jipf8tdirMST5fHxIzU9K91HkyXG04wCi9hZEQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCJMOKAG8AqrZh0953CTOt3Uo/I/tXphV9Tn5SYT5N02Sk0CO76awa97Mpc7GoI+M3bvt3J4g5NRgw1mz0/xfaBDoYcddhIE1LzGTXFFLMSyMT7bnGxHr8aSPSyJcJSRyHyIYfxfr3q84B12n+jpD84CYF2UN7X94tvFE4hwhqNX+XPA/0aNoEpdsMs7iem1mWG+VXZbhsOPVTZepC1sFVXS9TC2tGdDipv3ZeGE6DV6QquDtivk/4EBHrxaH3v3/5RIyuP1/gRfLzUR1lzOHknOFYALkOfasCwoRss2RrXS+vDDFRvY89EWAvHhpDTv/JVRpgpqNReWvdXJuKgkG2t','[\"saml20-idp-remote\"]','2024-03-14 15:37:18','2024-03-14 15:37:18',NULL,'https://ccbv9x-experienceday.com/','persistent');
/*!40000 ALTER TABLE `saml2_tenants` ENABLE KEYS */;

--
-- Table structure for table `tracks`
--

DROP TABLE IF EXISTS `tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tracks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hero_id` bigint NOT NULL DEFAULT '0',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `option` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `avatar` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracks`
--

/*!40000 ALTER TABLE `tracks` DISABLE KEYS */;
INSERT INTO `tracks` VALUES (101,1,'Track 1','Track 1','data-master-track-1','Track 1 - Data Master',NULL,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(102,1,'Track 2','Track 2','data-master-track-2','Track 2 - Data Master',NULL,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(103,1,'Track 3','Track 3','data-master-track-3','Track 3 - Data Master',NULL,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(201,2,'Track 1','Track 1','problem-solver-track-1','Track 1 - Problem Solver',NULL,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(202,2,'Track 2','Track 2','problem-solver-track-2','Track 2 - Problem Solver',NULL,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL),(203,2,'Track 3','Track 3','problem-solver-track-3','Track 3 - Problem Solver',NULL,NULL,NULL,'2024-03-14 15:37:19','2024-03-14 15:37:19',NULL);
/*!40000 ALTER TABLE `tracks` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `azure_id` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `refresh` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `full_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `title` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `department` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `area` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `avatar` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `heroes` json DEFAULT NULL,
  `state` json DEFAULT NULL,
  `point` double(8,2) NOT NULL DEFAULT '0.00',
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wp_id` (`azure_id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_title` (`title`),
  KEY `idx_department` (`department`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'WfZDcqZlei3sNaUWTF4juPbYP4Uu1EUkLNDOT4PYkMY','a2f7095f-5748-4c1f-8098-c0b617027032','ec929f28-dc7f-4660-b63d-9fe2fa5aa034',NULL,'mainv2002_gmail.com#EXT#@indochina.onmicrosoft.com','Mai, Nguyen Van_Keycom_Experienceday9x','123456','mainv2002@gmail.com','ABC','Sales & Commercial','North West',NULL,'[2]','{\"tracks\": {\"201\": 2011, \"202\": 2021, \"203\": 2031}, \"hero_id\": 2}',0.00,NULL,'2024-04-16 17:08:15','2024-04-16 17:08:15',NULL),(2,'opwFM1AfadQWrbNUbji7wYbun62RlrrOIfi_A21M8k4','a2f7095f-5748-4c1f-8098-c0b617027032','f7523c93-ae4b-4e4e-8ea3-5a51388f2fd3',NULL,'chunglam89_gmail.com#EXT#@indochina.onmicrosoft.com','Lam Chung Hoang_KeyCom_Experience Day','0938891007','chunglam89@gmail.com','It','IT','HCM',NULL,'[2, 1]','{\"tracks\": {\"101\": 1012, \"102\": 1021, \"103\": 1031}, \"hero_id\": 1}',0.00,NULL,'2024-05-28 07:10:29','2024-05-28 07:10:29',NULL),(3,'tnanhvu@coca-cola.com.vn','a2f7095f-5748-4c1f-8098-c0b617027032','8d82e8c1-e59d-467d-bf6e-d09d4ae992c9',NULL,'tnanhvu@coca-cola.com.vn','Vu, Tran Ngoc Anh','','tnanhvu@coca-cola.com.vn','','','',NULL,NULL,NULL,0.00,NULL,'2024-04-15 07:19:39','2024-04-15 07:19:39',NULL),(4,'bIWYETfufayXJa2aYnYvUCuC4l_o-W8qYBZ8mOB47Co','a2f7095f-5748-4c1f-8098-c0b617027032','8d82e8c1-e59d-467d-bf6e-d09d4ae992c9',NULL,'tnanhvu@coca-cola.com.vn','Vu, Tran Ngoc Anh','','tnanhvu@coca-cola.com.vn','','','',NULL,NULL,NULL,0.00,NULL,'2024-04-15 07:20:44','2024-04-15 07:20:44',NULL),(5,'s5dwFr22IZrHwqg4ygqm7u_p4A1SnGRZ929gVq4R3HI','a2f7095f-5748-4c1f-8098-c0b617027032','8a0eb398-565b-4950-b9d3-7b2d88f3312d',NULL,'NhanDoan.C@coca-cola.com.vn','Nhan, Doan Le Thanh [C]','','NhanDoan.C@coca-cola.com.vn','','','',NULL,NULL,NULL,0.00,NULL,'2024-04-15 07:21:36','2024-04-15 07:21:36',NULL),(6,'H8M3re3sq7wKayU1ip0ZXZZHrEkQQqSswT7pIEihBHo','a2f7095f-5748-4c1f-8098-c0b617027032','7a386f01-e700-4743-a76f-d31a7c7b5ad3',NULL,'thanh.do@coca-cola.com.vn','Thanh, Do Huu','1','thanh.do@coca-cola.com.vn','Q','Sales & Commercial','HCM',NULL,'[2, 1]','{\"tracks\": {\"101\": 1014, \"102\": 1024, \"103\": 1031}, \"hero_id\": 1}',0.00,NULL,'2024-05-03 04:36:36','2024-05-03 04:36:36',NULL),(7,'ieyrPVhp8L66fN6arY5u62TRC1CirDnKsWSVHxP2x14','a2f7095f-5748-4c1f-8098-c0b617027032','80861388-7ad1-4cc1-8a59-a98e0b17add2',NULL,'trang.nguyenm@coca-cola.com.vn','Trang, Nguyen Minh','0906591006','trang.nguyenm@coca-cola.com.vn','People','People','HO (trụ sở chính)',NULL,'[2]','{\"tracks\": {\"201\": 2011, \"202\": 2024, \"203\": 2035}, \"hero_id\": 2}',0.00,NULL,'2024-04-25 04:03:32','2024-04-25 04:03:32',NULL),(8,'0X5WqEwjMP7EB1wSxX6M8bAXNt9TF4bXiHUrgmXTty8','a2f7095f-5748-4c1f-8098-c0b617027032','f42b02f2-7b91-429f-a435-ef35a84f9143',NULL,'tam.bac@coca-cola.com.vn','Tam, Bac Tran Ngoc','0989045504','tam.bac@coca-cola.com.vn','Culture','People','HCM',NULL,'[2]','{\"tracks\": {\"201\": 2014, \"202\": 2021, \"203\": 2031}, \"hero_id\": 2}',0.00,NULL,'2024-05-09 03:50:08','2024-05-09 03:50:08',NULL),(9,'wgBeV-EtFCmOxMH14WU9uSAUgsTjVUe38AxISrSKgUg','a2f7095f-5748-4c1f-8098-c0b617027032','700cb91a-74fd-434e-a7ed-7e5b9431a634',NULL,'hntruc@coca-cola.com.vn','Truc, Huynh Thi Ngoc','','hntruc@coca-cola.com.vn','','','',NULL,NULL,NULL,0.00,NULL,'2024-04-30 08:39:15','2024-04-30 08:39:15',NULL),(10,'HY_IIF42tILQTDzWRR2CtgG71txRfFgwXcXeVy87KmQ','a2f7095f-5748-4c1f-8098-c0b617027032','918f9597-9324-4871-9aef-f872a308e106',NULL,'thao.let@coca-cola.com.vn','Thao, Le Thi Thu','123456','thao.let@coca-cola.com.vn','EB Lead','People','HO (trụ sở chính)',NULL,'[3]','{\"tracks\": {\"201\": 2011, \"202\": 2021, \"203\": 2031}, \"hero_id\": 3}',0.00,'{\"hero_3\": {\"track_1\": 201, \"track_2\": 202, \"track_3\": 203}}','2024-05-03 04:43:59','2024-05-03 04:43:59',NULL),(11,'DG2POeCyzK5LV3TfxcY7aPkyDe3uV72qSNwWXnHaaiw','a2f7095f-5748-4c1f-8098-c0b617027032','7fe797cc-5061-4768-b9db-f0ff73a57064',NULL,'khoa.huynh@coca-cola.com.vn','Khoa, Huynh Le Quy','','khoa.huynh@coca-cola.com.vn','','','',NULL,NULL,NULL,0.00,NULL,'2024-05-03 04:38:18','2024-05-03 04:38:18',NULL),(12,'yG0LBLnEpIzzKnD7X7qUQ355fe8kO7yHL27UTHSc6vM','a2f7095f-5748-4c1f-8098-c0b617027032','3d5ef40c-14d9-47b4-84c3-ee9ff94f24c3',NULL,'hiep.nguyenh@coca-cola.com.vn','Hiep, Nguyen Hoang','0909090909','hiep.nguyenh@coca-cola.com.vn','hiep','People','HO (trụ sở chính)',NULL,'[3]','{\"tracks\": {\"201\": 2011, \"202\": 2021, \"203\": 2031}, \"hero_id\": 3}',0.00,'{\"hero_3\": {\"track_1\": 201, \"track_2\": 202, \"track_3\": 203}}','2024-05-03 04:44:21','2024-05-03 04:44:21',NULL),(13,'HUU2w2D2SOdmL_DI8k9EHmY5OXmFFF8a8Dir2kyAy5k','a2f7095f-5748-4c1f-8098-c0b617027032','9fda82ab-fedb-44a7-a680-9832cd396fe4',NULL,'nguyen.huyen@coca-cola.com.vn','Huyen, Nguyen Thi Thanh','','nguyen.huyen@coca-cola.com.vn','','','',NULL,NULL,NULL,0.00,NULL,'2024-05-03 04:51:08','2024-05-03 04:51:08',NULL),(14,'ohZ6HZImgACowa5Vp_4rXBvytDqqDD0djQI4_S0Etq8','a2f7095f-5748-4c1f-8098-c0b617027032','2ec5cc4e-220f-41fb-97f0-608460cc9f08',NULL,'hoa.luu@coca-cola.com.vn','Hoa, Luu Quynh','000','hoa.luu@coca-cola.com.vn','HR','People','HO (trụ sở chính)',NULL,'[3]','{\"tracks\": {\"101\": 1011, \"102\": 1021, \"103\": 1031}, \"hero_id\": 3}',0.00,'{\"hero_3\": {\"track_1\": 101, \"track_2\": 102, \"track_3\": 103}}','2024-05-06 07:41:37','2024-05-06 07:41:37',NULL),(15,'Miw_iIaFV95Rl7GL6U2BK8-UrSklA7QvkFU50Y8LUiQ','a2f7095f-5748-4c1f-8098-c0b617027032','b5fa34da-8c8a-4637-b184-7bc92fa4cd9d',NULL,'thinh.nguyenqu@coca-cola.com.vn','Thinh, Nguyen Quoc','666','thinh.nguyenqu@coca-cola.com.vn','hoa','Sales & Commercial','HO (trụ sở chính)',NULL,NULL,NULL,0.00,NULL,'2024-05-09 03:55:32','2024-05-09 03:55:32',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-28 15:21:00
